import scipy.io as sio
import numpy as np

import GFCNCenter
import GFCN_DataHandle


def GFCN_demo():
    mat_names = ["D:\\Python\\GFCN\\datasets\\train\\BridgesTrain.mat"]
    for name_i in range(0, len(mat_names)):
        mat_name = mat_names[name_i]
        data_array = sio.loadmat(mat_name)
        data_array = data_array['data_array']

        data_array = GFCN_DataHandle.GFCN_DataHandle(data_array)
        cluster_X = data_array[:, :-1]
        cluster_K = len(np.unique(data_array[:, -1]))

        idx, center, loss_m_list, loss_k_list, loss_n_list, loss_mkn_list = GFCNCenter.train_gfcn(cluster_X, cluster_K, epochs=10, alpha=1, beta=1)
        pass


if __name__ == "__main__":
    GFCN_demo()
    pass
