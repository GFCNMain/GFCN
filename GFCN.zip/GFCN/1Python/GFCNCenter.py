import numpy as np
import torch
import torch.nn.functional as F
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
import GFCNet


def train_gfcn(X, k, epochs=10, alpha=0.1, beta=0.01):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    n, d = X.shape

    # 1数据预处理
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    x_tensor = torch.tensor(X_scaled, dtype=torch.float32).to(device)

    # 2构建图
    from sklearn.neighbors import kneighbors_graph
    adj = kneighbors_graph(X_scaled, n_neighbors=15, mode='connectivity', include_self=False)
    edge_index = torch.tensor(np.array(adj.nonzero()), dtype=torch.long).to(device)

    model = GFCNet.GFCNet(input_dim=d, n_clusters=k).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

    # 21初始化中心
    model.eval()
    with torch.no_grad():
        z_init, _, _ = model(x_tensor, edge_index)
        kmeans = KMeans(n_clusters=k, n_init=20, random_state=42).fit(z_init.cpu().numpy())
        model.cluster_centers.data = torch.tensor(kmeans.cluster_centers_).to(device)


    target_p = None
    loss_m_list = []
    loss_k_list = []
    loss_n_list = []
    loss_mkn_list = []
    for epoch in range(epochs):
        model.train()
        optimizer.zero_grad()
        z, q, x_recon = model(x_tensor, edge_index)

        if epoch % 2 == 0:
            target_p = GFCNet.target_distribution(q).detach()

        # 22损失函数
        loss_mse = F.mse_loss(x_recon, x_tensor)
        loss_kl = F.kl_div(q.log(), target_p, reduction='batchmean')
        loss_near = torch.mean((z[edge_index[0]] - z[edge_index[1]]) ** 2)  # 拉近邻居

        # total_loss
        total_loss = loss_mse + alpha * loss_kl + beta * loss_near

        total_loss.backward()
        optimizer.step()

        loss_m_list.append(loss_mse.item())
        loss_k_list.append(loss_kl.item())
        loss_n_list.append(loss_near.item())
        loss_mkn_list.append(total_loss.item())
        if (epoch + 1) % 2 == 0:
            print(f"Epoch {epoch + 1}/{epochs}, Loss: {total_loss.item():.6f} (MSE: {loss_mse.item():.6f}, KL: {loss_kl.item():.6f})")

    # 3计算特征平均值得到质心
    model.eval()
    with torch.no_grad():
        _, q, _ = model(x_tensor, edge_index)
        idx = q.argmax(1).cpu().numpy() + 1
        centers = np.array([X[idx == i].mean(axis=0) for i in range(1, k + 1)])

    return idx, centers, loss_m_list, loss_k_list, loss_n_list, loss_mkn_list

