import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv


class GFCNet(nn.Module):
    def __init__(self, input_dim, hidden_dim=128, embed_dim=64, n_clusters=10):
        super(GFCNet, self).__init__()
        # 1Encoder
        self.conv1 = GCNConv(input_dim, hidden_dim)
        self.conv2 = GCNConv(hidden_dim, embed_dim)

        # 2Decoder
        self.decoder = nn.Sequential(
            nn.Linear(embed_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, input_dim)
        )

        self.cluster_centers = nn.Parameter(torch.Tensor(n_clusters, embed_dim))
        nn.init.xavier_uniform_(self.cluster_centers)

    def forward(self, x, edge_index):
        h = F.relu(self.conv1(x, edge_index))
        z = self.conv2(h, edge_index)
        x_recon = self.decoder(z)
        # Q
        dist = torch.sum((z.unsqueeze(1) - self.cluster_centers) ** 2, dim=2)
        q = 1.0 / (1.0 + dist)
        q = (q.t() / torch.sum(q, dim=1)).t()

        return z, q, x_recon


def target_distribution(q):
    weight = q ** 2 / q.sum(0)
    return (weight.t() / weight.sum(1)).t()

