import numpy as np



def GFCN_DataHandle(data_array):
    """
    0-1归一化
    """
    if np.any(data_array[:, :-1] < 0):
        data_X = data_array[:, :-1]
        data_Y = data_array[:, -1].reshape(-1, 1)

        # 归一化公式：(x - min) / (max - min)
        min_vals = np.min(data_X, axis=0)
        max_vals = np.max(data_X, axis=0)

        range_vals = max_vals - min_vals
        range_vals[range_vals == 0] = 1e-8
        data_X = (data_X - min_vals) / range_vals

        dataHanled = np.hstack((data_X, data_Y))
    else:
        dataHanled = data_array

    return dataHanled
