function similarity = fuzzySimilarity(label_i_center, label_i_features, kernelType, sigma)
    similarities = zeros(size(label_i_features, 1), 1);
    norm_label_i_center = norm(label_i_center);
    for label_i_samples_i = 1:size(label_i_features, 1)
        % 1���Ҿ���
        label_i_samples_vec = label_i_features(label_i_samples_i, :);
        dot_product = dot(label_i_center, label_i_samples_vec);
        norm_sample = norm(label_i_samples_vec);
        x_y_distance_Sim = dot_product / (norm_label_i_center * norm_sample + eps);
        x_y_distance = 1 - x_y_distance_Sim;
        x_y_distanceSqrt = x_y_distance.^2;

        % a3-1 �������

        switch kernelType % 'St' or 'TheTa_sigma'
            case 'St'
                kernels = 1 - exp( -x_y_distanceSqrt / (2*sigma^2) );
                %kernels = sum( ones(size(x_y_distanceSqrt)) - exp( -x_y_distanceSqrt / (2*sigma^2) ) );
            case 'TheTa_sigma'
                x_y_distanceSqrt = abs(x_y_distance);
                kernels = sqrt( 1 - (exp( -x_y_distanceSqrt / (2*sigma) )).^2 );
                %kernels = sqrt( sum( ones(size(x_y_distanceSqrt)) - (exp( -x_y_distanceSqrt / (2*sigma) )).^2 ) );
        end
        similarities(label_i_samples_i) = kernels;
    end
    similarity = similarities;
end