%%% G_Experiment
% create by ZiLng Lin
% 2026-2-15

%% GFCN+fs
clc;
clear All;

str_data_name = {'Bridges'};
str_train_name = {'BridgesTrain.mat'};
str_train_center_name = {'BridgesTrainCenter_GFCN.mat'};
str_test_name = {'BridgesTest.mat'};
str_function_name = {'fs_result_','acc_result_','cd_result_'};

algorithmName = 'GFCN';
filePath = './GFCN/';

for i = 1:1%length(str_data_name)
    %0 load
    mat_name = str_train_name{i};
    load (mat_name);
    mat_center_name = str_train_center_name{i};
    load (mat_center_name);

    data_array = MHFS_DataHandle(data_array); %% �ȹ�һ��
    data_array = GFCN_get_K_samples(data_array, 7, center, 'St', 0.2);

    %1 algorithm
    delta = 0.2;
    sigma = 0.2;
    kernelType = 'St';
    
    [allRankFeatures, reducedFeatures, otherRankFeatures, irrelevantFeatures, ~] = MHFSMain(data_array, tree, kernelType, sigma, delta);
end